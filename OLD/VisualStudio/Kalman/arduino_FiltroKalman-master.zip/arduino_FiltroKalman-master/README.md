# FiltroKalmanArduino

Filtro Kalman para Arduino, actualemente la he probado con Arduino Uno, Arduino Leonardo, CircuitPlayGround, ESP8266, ESP32, Arduino M0, Adafruit Feather M0.

Es un filtro muy potente que funciona para eliminar ruidos blancos(https://es.wikipedia.org/wiki/Ruido_blanco), para mas informacion del filtro kalman https://es.wikipedia.org/wiki/Filtro_de_Kalman

Esta biblioteca esta basada en: https://github.com/micuat/ofxUkf
